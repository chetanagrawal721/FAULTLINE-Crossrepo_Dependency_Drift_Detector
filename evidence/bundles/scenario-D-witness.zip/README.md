# Faultline evidence bundle

This bundle records one **witness**: A specific interaction passed in the reference world and failed in the consumer world, reproducibly (3 fresh executions each, identical normalized failure signature), under the environment recorded here.

- Entry point: `acme_models.web` (oracle `o_import` 1.0.0)
- Failure: `ImportError`: cannot import name 'url_quote' from 'werkzeug.urls' (<site>/werkzeug/urls.py)
- Origin: `flask.app`
- Reference world: `w_4bbb68b1d9f83a4b8c3a9cc0df8a13c6b8e9172a`  Consumer world: `w_bbad6276629618e55fb90cdbaae0856f180329f0`
- Artifact content hash: `a_a5d885a78dab3ac4bc8894ca251b9ead4de2867b`
- Runs: 3 reference passes and 3 consumer failures, all freshly executed (see `runs/`).

## What this does not claim
- that the dependency upgrade is incompatible in general
- that other interactions, inputs or code paths are affected
- that the minimal cause is known (attribution is a separate result)

## Checking it
Every file is listed in `manifest.json` with its sha256. Run `python -m faultline.witnesses.bundle <bundle.zip>`
to verify integrity and consistency. `REPRODUCE.md` explains how to re-run the witness.
