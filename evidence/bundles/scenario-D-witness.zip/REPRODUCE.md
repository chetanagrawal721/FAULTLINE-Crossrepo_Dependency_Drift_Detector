# Re-running this witness

1. Verify the bundle: `python -m faultline.witnesses.bundle bundle.zip` (no network, no Docker needed).
2. The two worlds are fully described by `worlds/*.world.json` and `worlds/*.lock.txt` (exact versions and wheel hashes).
   Build each as a virtual environment from those wheels only (`pip install --no-deps --require-hashes -r <lock>`).
3. Put `artifact/tree/src` on `PYTHONPATH` and run the oracle in `plan/oracle_plan.json` in each world, three times,
   with network access disabled. Expect the reference to pass and the consumer to fail with the signature in `witness.json`.

Automated replay does these steps: `python -m faultline.witnesses.replay bundle.zip` (needs Docker and the Faultline sandbox).
It reports exactly one of EXACT_REPRODUCTION, ENVIRONMENT_LIMITED or NON_REPRODUCIBLE, with reasons. Wheels are fetched only by
sha256 from the lock files; nothing is ever fetched by branch or tag.
