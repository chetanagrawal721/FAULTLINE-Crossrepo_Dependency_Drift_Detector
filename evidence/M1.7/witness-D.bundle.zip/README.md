# Faultline evidence bundle

This bundle records one **witness**: A specific interaction passed in the reference world and failed in the consumer world, reproducibly (3 fresh executions each, identical normalized failure signature), under the environment recorded here.

- Entry point: `acme_models.web` (oracle `o_import` 1.0.0)
- Failure: `ImportError`: cannot import name 'url_quote' from 'werkzeug.urls' (<site>/werkzeug/urls.py)
- Origin: `flask.app`
- Reference world: `w_8511168f2c60a07ee7f7619a7fa81678bb84824e`  Consumer world: `w_46bfce3e9bd6dc4c8679280100e34f853297f018`
- Artifact content hash: `a_b52d4d29d5fa2ca3c31b6b1e9f16298b66f23624`
- Runs: 3 reference passes and 3 consumer failures, all freshly executed (see `runs/`).

## What this does not claim
- that the dependency upgrade is incompatible in general
- that other interactions, inputs or code paths are affected
- that the minimal cause is known (attribution is a separate result)

## Checking it
Every file is listed in `manifest.json` with its sha256. Run `python -m faultline.witnesses.bundle <bundle.zip>`
to verify integrity and consistency. `REPRODUCE.md` explains how to re-run the witness.
