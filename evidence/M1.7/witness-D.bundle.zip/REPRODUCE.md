# Re-running this witness

1. Verify the bundle: `python -m faultline.witnesses.bundle bundle.zip` (no network, no Docker needed).
2. The two worlds are fully described by `worlds/*.world.json` and `worlds/*.lock.txt` (exact versions and wheel hashes).
   Build each as a virtual environment from those wheels only (`pip install --no-deps --require-hashes -r <lock>`).
3. Put `artifact/tree/src` on `PYTHONPATH` and run the oracle in `plan/oracle_plan.json` in each world, three times,
   with network access disabled. Expect the reference to pass and the consumer to fail with the signature in `witness.json`.

Automated replay (milestone M5.2) will do these steps and report EXACT_REPRODUCTION, ENVIRONMENT_LIMITED or
NON_REPRODUCIBLE. Until then this bundle proves what was observed and on exactly which inputs; it does not itself
re-execute anything.
